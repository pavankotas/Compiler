import os, sys

filename = 'C:/Users/saria/Anaconda3/Lib/site-packages/training.log'
f=open(filename, "r")
if f.mode == 'r':
    contents = f.read()
    print(contents)